package com.horizonverticalviews.jade.library;

/**
 * Created by Administrator on 2018/6/6.
 */

public interface ViewOperationDelegate {
    public boolean intercept();
}
